/*
$(document).ready(function () {
    if(window.location.href.indexOf("#comment") > -1) {
       var id = window.location.hash.substr(1);
	   alert(id);
	   $('#'+id).addClass('selected');
    }
});
*/