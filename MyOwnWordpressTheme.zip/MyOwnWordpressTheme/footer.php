	<div id="footer">
		<div class="contact-link">
		<a href="mailto:andyjanuar@gmail.com" class="wborder icon-email"><i class="fa fa-envelope" aria-hidden="true"></i> andyjanuar@gmail.com</a>
			<a href="https://www.facebook.com/andyjanuar" target="_blank" class="icon-facebook"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
			<a href="https://www.instagram.com/orioreno/" target="_blank" class="icon-instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
			<a href="https://www.linkedin.com/in/andy-januar-46201760" target="_blank" class="icon-linkedin"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
			
		</div>
	</div>
<?php wp_footer(); ?>
</body>
</html>